# Security Policy

## Supported Versions

The following versions are supported:

| Version | Supported          |
| ------- | ------------------ |
| 8.x-3.x   | :white_check_mark: |
| 8.x-2.x   | :x:                |
| 8.x-1.x   | :x:                |

## Reporting a Vulnerability

Please report Security issues on the drupal.org issue queue
over at https://www.drupal.org/project/issues/gin
